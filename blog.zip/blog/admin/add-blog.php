<?php
require_once 'header.php';
require_once '../vendor/autoload.php';
$category = new App\classes\Category();
$blog = new App\classes\Blog();

$selectActiveCategory = $category->selectActiveCategory();

if (isset($_POST['add_blog'])) {
    $addMessage = $blog->addBlog($_POST);
}
?>
<div class="row">

    <div class="col-lg-12">
        <section class="card">
            <header class="card-header">
                <h4>Make a Blog Post</h4>
            </header>
            <div class="card-body">
                <form action="" method="POST" enctype="multipart/form-data">
                    <?php if (isset($addMessage)) { ?>

                        <div class="alert alert-success text-center" role="alert" style="color: red;"><?php echo $addMessage; ?><button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button></div>

                    <?php
                    } else {
                        
                    }
                    ?>

                    <div class="form-group row">
                        <label for="cat_id
                               " class="col-sm-3 col-form-label">Category Name</label>
                        <div class="col-sm-9">
                            <select id="cat_id" name="cat_id" class="form-control" required="">
                                <option value="">Select Category</option>
                                <?php while ($row1 = mysqli_fetch_assoc($selectActiveCategory)) { ?>
                                  <option value="<?php echo $row1['id']; ?>"><?php echo $row1['cat_name']; ?></option>
                                                        
                                           <?php         }?>
                              
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="title" class="col-sm-3 col-form-label">Blog Title</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="title" placeholder="Blog Title" name="title" required="">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="content" class="col-sm-3 col-form-label">Blog Content</label>
                        <div class="col-sm-9">
                            <!--Summernote start-->


                            <textarea class="summernote" name="content" required=""></textarea>



                            <!--Summernote end-->
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="photo" class="col-sm-3 col-form-label">Upload Image</label>
                        <div class="col-sm-9">
                            <input type="file" id="photo" name="photo">
                        </div>
                    </div>

                    <fieldset class="form-group">
                        <div class="row">
                            <legend class="col-form-label col-sm-3 pt-0">Status</legend>
                            <div class="col-sm-9">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="status" id="gridRadios1" value="1" checked="">
                                    <label class="form-check-label" for="gridRadios1">
                                        Active
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="status" id="gridRadios2" value="0">
                                    <label class="form-check-label" for="gridRadios2">
                                        Inactive
                                    </label>
                                </div>

                            </div>
                        </div>
                    </fieldset>

                    <div class="form-group row">
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-primary" name="add_blog">Post Now</button>
                        </div>
                    </div>
                </form>
            </div>
        </section>

    </div>
</div>
<?php
require_once 'footer.php';
?>            
