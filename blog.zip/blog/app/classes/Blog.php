<?php

namespace App\classes;

use App\classes\Database;

class Blog {

    public function addBlog($data) {


        $cat_id = $data['cat_id'];
        $title = mysqli_real_escape_string(Database::dbCon(), $data['title']);
        $content = mysqli_real_escape_string(Database::dbCon(), $data['content']);
        $photo = $_FILES['photo']['name'];
        $photo1 = explode('.', $photo);
        $photo2 = end($photo1);
        $photo3 = date('Ymdhis') . '.' . $photo2;

        $post_by = $_SESSION['name'];

        $status = $data['status'];


        $query = "INSERT INTO `add_blog`(`cat_id`, `title`, `content`, `photo`, `post_by`, `status`) VALUES ('$cat_id', '$title', '$content', '$photo3', '$post_by', '$status');";
        $result = mysqli_query(Database::dbCon(), $query);

        if (isset($result)) {
            move_uploaded_file($_FILES['photo']['tmp_name'], '../uploads/' . $photo3);
            return $successMessage = "Successfully Posted! Add New One.";
        } else {
            return $failMessage = "Post Not Successful. Please Try Again.";
        }
    }

    public function selectAllPosts() {
        $query = "SELECT `add_blog`.*, `add_category`.`cat_name`
        FROM `add_blog`
        INNER JOIN `add_category`ON `add_blog`.`cat_id`=`add_category`.`id` ORDER BY `id`DESC";
        $result = mysqli_query(Database::dbCon(), $query);
        return $result;
    }
      public function selectActivePosts() {
        $query = "SELECT `add_blog`.*, `add_category`.`cat_name`
        FROM `add_blog`
        INNER JOIN `add_category`ON `add_blog`.`cat_id`=`add_category`.`id` WHERE `add_blog`.`status` = '1' ORDER BY `id`DESC";
        $result = mysqli_query(Database::dbCon(), $query);
        return $result;
    }

    public function delete($id) {
        $query = "DELETE FROM `add_blog` WHERE `id`= '$id'";
        return mysqli_query(Database::dbCon(), $query);
    }

    public function inactivate($id) {
        $query = "UPDATE `add_blog` SET `status`='0' WHERE `id`= '$id';";
        mysqli_query(Database::dbCon(), $query);
    }

    public function activate($id) {
        $query = "UPDATE `add_blog` SET `status`='1' WHERE `id`= '$id';";
        mysqli_query(Database::dbCon(), $query);
    }

    //$id = '' because if anyone cut the id in browser so that no error can occur.
    public function selectData($id = '') {
        $query = "SELECT * FROM `add_blog` WHERE `id`='$id'";
        return mysqli_query(Database::dbCon(), $query);
    }

    public function update($data) {
        $id = $data['id'];
        $cat_id = $data['cat_id'];
        $title = mysqli_real_escape_string(Database::dbCon(), $data['title']);
        $content = mysqli_real_escape_string(Database::dbCon(), $data['content']);
        $photo = $_FILES['photo']['name'];
        $photo1 = explode('.', $photo);
        $photo2 = end($photo1);
        $photo3 = date('Ymdhis') . '.' . $photo2;

        $post_by = $_SESSION['name'];

        $status = $data['status'];
        if ($_FILES['photo']['name'] == NULL) {
            $query = "UPDATE `add_blog` SET `cat_id`='$cat_id',`title`='$title',`content`='$content',`post_by`='$post_by',`status`='$status' WHERE `id`='$id'";
        } else {
            $photo = $_FILES['photo']['name'];
            $photo1 = explode('.', $photo);
            $photo2 = end($photo1);
            $photo3 = date('Ymdhis') . '.' . $photo2;
            $query = "UPDATE `add_blog` SET `cat_id`='$cat_id',`title`='$title',`content`='$content',`photo`='$photo3',`post_by`='$post_by',`status`='$status' WHERE `id`='$id'";
            move_uploaded_file($_FILES['photo']['tmp_name'], '../uploads/' . $photo3);
        }

        $result = mysqli_query(Database::dbCon(), $query);
        if ($result) {
            header('Location: manage-blog.php');
        } else {
            header('Location: update-blog.php');
        }
    }
public function selectSinglePosts($id = '') {
        $query = "SELECT * FROM `add_blog` WHERE `status`='1'AND `id`='$id'";
        return mysqli_query(Database::dbCon(), $query);
    }
   public function categoryPosts($id = '') {
        $query = "SELECT * FROM `add_blog` WHERE `status`='1' AND `cat_id`='$id' ORDER BY `id` DESC";
        return mysqli_query(Database::dbCon(), $query);
    }
      public function searchPosts($search = '') {
        $query = "SELECT * FROM `add_blog` WHERE `status`='1' AND (`content` LIKE '%$search%' OR `title` LIKE '%$search%') ORDER BY `id` DESC";
        return mysqli_query(Database::dbCon(), $query);
    }
   
   
}
