<?php


namespace App\classes;


class Database {
    public function dbCon() {
        $host = "localhost";
        $user = "root";
        $password = "";
        $database = "blog";
        return $link = mysqli_connect($host, $user, $password, $database);
        
    }
}
