<?php

namespace App\classes;

use App\classes\Database;

class Category {

    public function addCategory($data) {
        $cat_name = $data['cat_name'];
        $status = $data['status'];

        $query = "INSERT INTO `add_category`(`cat_name`, `status`) VALUES ('$cat_name', '$status')";
        $result = mysqli_query(Database::dbCon(), $query);

        if ($result) {
            return $successMessage = "Data Save Success! Add New One.";
        } else {
            return $failMessage = "Data Not Saved.";
        }
    }

    public function selectCategory() {
        $query = "SELECT * FROM `add_category`";
        $result = mysqli_query(Database::dbCon(), $query);
        return $result;
    }
 public function selectActiveCategory() {
        $query = "SELECT * FROM `add_category` WHERE `status`=1";
        $result = mysqli_query(Database::dbCon(), $query);
        return $result;
    }
    public function inactivate($id) {
        $query = "UPDATE `add_category` SET `status`='0' WHERE `id`= '$id';";
        mysqli_query(Database::dbCon(), $query);
    }

    public function activate($id) {
        $query = "UPDATE `add_category` SET `status`='1' WHERE `id`= '$id';";
        mysqli_query(Database::dbCon(), $query);
    }

    public function delete($id) {
        $query = "DELETE FROM `add_category` WHERE `id`= '$id'";
        return mysqli_query(Database::dbCon(), $query);
    }

    //$id = '' because if anyone cut the id in browser so that no error can occur.
    public function selectData($id = '') {
        $query = "SELECT * FROM `add_category` WHERE `id`='$id'";
        return mysqli_query(Database::dbCon(), $query);
    }
    
    public function update($data) {
        $id = $data['id'];
        $cat_name = $data['cat_name'];
        $status = $data['status'];
        
        $query = "UPDATE `add_category` SET `cat_name`='$cat_name',`status`='$status' WHERE `id`='$id'";
        return mysqli_query(Database::dbCon(), $query);
        
        
    }
     public function selectCategoryTitle($id = '') {
        $query = "SELECT * FROM `add_category` WHERE `id`='$id'";
        return mysqli_query(Database::dbCon(), $query);
    }
   
}
