
<?php
require_once 'header.php';

require_once 'vendor/autoload.php';
$category = new App\classes\Category();
$selectActiveCategory = $category->selectActiveCategory();
$blog = new App\classes\Blog();
$data = $blog->selectActivePosts();

?>

<!-- Page Content -->
<div class="container">

    <div class="row">

        <!-- Blog Entries Column -->
        <div class="col-md-8">
            <?php if(isset($_GET['search'])){
              $search =  $_GET['search'];
              $search_post = $blog->searchPosts($search);
              $search_post2 = mysqli_num_rows($search_post);
              
                
                ?>
            <h1 class="my-4">Search Results:-
               
            </h1>
              <?php
            if($search_post2>0){
                
            
            while ($row3 = mysqli_fetch_assoc($search_post)) {
                ?>
                <div class="card mb-4">
                    <img class="card-img-top" src="uploads/<?php echo $row3['photo']; ?>" alt="Card image cap" style="width:100%; height: 300px;">
                    <div class="card-body">
                        <h2 class="card-title"><?php echo $row3['title']; ?></h2>
                        <p class="card-text"><?php echo substr($row3['content'],0,800); ?>....</p>
                        <a href="single-post.php?id=<?php echo $row3['id']; ?>" class="btn btn-primary">Read More &rarr;</a>
                    </div>
                    <div class="card-footer text-muted">
                        Posted on <?php echo $row3['create_time']; ?> by 
                        <a href="#"><?php echo $row3['post_by']; ?></a>
                    </div>
                </div>
           

            <?php } } else { ?>
            <h2 class="my-4" style="color: #007bff;">Data Not Found!
               
            </h2>
            <?php
     
 } ?>
                
      <?php      } else { ?>
                
        

           
           

            <!-- Blog Post -->
            <?php
            
            while ($row = mysqli_fetch_assoc($data)) {
                ?>
                <div class="card mb-4">
                    <img class="card-img-top" src="uploads/<?php echo $row['photo']; ?>" alt="Card image cap" style="width:100%; height: 300px;">
                    <div class="card-body">
                        <h2 class="card-title"><?php echo $row['title']; ?></h2>
                        <p class="card-text"><?php echo substr($row['content'],0,800); ?>....</p>
                        <a href="single-post.php?id=<?php echo $row['id']; ?>" class="btn btn-primary">Read More &rarr;</a>
                    </div>
                    <div class="card-footer text-muted">
                        Posted on <?php echo $row['create_time']; ?> by 
                        <a href="#"><?php echo $row['post_by']; ?></a>
                    </div>
                </div>
           

            <?php } ?>
            <?php    } ?> 

            <!-- Pagination -->
            <ul class="pagination justify-content-center mb-4">
                <li class="page-item">
                    <a class="page-link" href="#">&larr; Older</a>
                </li>
                <li class="page-item disabled">
                    <a class="page-link" href="#">Newer &rarr;</a>
                </li>
            </ul>

        </div>

        <?php require_once 'sidebar.php'; ?>

    </div>
    <!-- /.row -->

</div>
<!-- /.container -->

<?php require_once 'footer.php'; ?>

