<?php
require_once 'header.php';
require_once '../vendor/autoload.php';

$category = new App\classes\Category();
$data = $category->selectCategory();


?>
<div class="row">
    <div class="col-sm-12">
        <section class="card">
            <header class="card-header">
                All Categories
                <span class="tools pull-right">
                    <a href="javascript:;" class="fa fa-chevron-down"></a>
                    <a href="javascript:;" class="fa fa-times"></a>
                </span>
            </header>
            <div class="card-body">
                <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table">
                        <thead>



                            <tr>
                                <th>SI</th>
                                <th>Category Name</th>
                                <th>Status</th>
                                <th class="hidden-phone">Action</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sl = 1;
                            while ($row = mysqli_fetch_assoc($data)) {
                                ?>
                                <tr class="gradeX">
                                    <td><?php echo $sl; ?></td>
                                    <td><?php echo $row['cat_name']; ?></td>

                                    <td><?php if ($row['status'] == 1) { ?>
                                            <a class="btn btn-success btn-sm btn-block"><li class="fa fa-arrow-circle-o-up"></li> Active</a>
                                            <a class="btn btn-warning btn-sm btn-block" href="status.php?id=<?php echo $row['id']; ?>&table=add_category&inactivate=inactivate" ><li class="fa fa-arrow-circle-o-down"></li> Click to Inactivate</a><?php } ?>
    <?php if ($row['status'] == 0) { ?>
                                            <a class="btn btn-warning btn-sm btn-block"><li class="fa fa-arrow-circle-o-down"></li> Inactive</a>
                                            <a class="btn btn-success btn-sm btn-block" href="status.php?id=<?php echo $row['id']; ?>&table=add_category&activate=activate"><li class="fa fa-arrow-circle-o-up"></li> Click to Activate</a><?php } ?>
                                    </td>


                                    <td><a class="btn btn-info btn-sm btn-block" href="update_category.php?id=<?php echo $row['id']; ?>&table=add_category"><li class="fa fa-pencil-square-o"></li> Edit</a>
                                        <a class="btn btn-danger btn-sm btn-block" href="delete.php?id=<?php echo $row['id']; ?>&table=add_category"><li class="fa fa-trash-o"></li> Delete</a></td>

                                </tr>
    <?php $sl++;
} ?>  
                        </tbody>

                    </table>
                </div>
            </div>
        </section>
    </div>
</div>
<?php
require_once 'footer.php';
?>