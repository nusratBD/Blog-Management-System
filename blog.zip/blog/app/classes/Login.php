<?php
use App\classes\Database;

namespace App\classes;
class Login {
    //=>For User Login:
    public function loginCheck($data) {
        $username = $data['username'];
        $password = md5($data['password']);
        $query = "SELECT * FROM `user` WHERE `username` = '$username' AND `password`= '$password';";
        $result = mysqli_query(Database::dbCon(), $query);
        if ($result) {
            if(mysqli_num_rows($result)==1){
                $row = mysqli_fetch_assoc($result);
                session_start();
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['name'] = $row['name'];
                $_SESSION['username'] = $row['username'];
                header('Location: index.php');
            }  else {
            $loginError = "Username Or Password Invalid";
            return $loginError;
        }
            
        }
    }
}
