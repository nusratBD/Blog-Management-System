<?php

require_once '../vendor/autoload.php';

$category = new App\classes\Category();

$blog = new App\classes\Blog();

if (isset($_GET['inactivate'])&&isset($_GET['table'])) {
    $id = $_GET['id'];
    $category->inactivate($id);
    header('Location: manage-category.php');
}
if (isset($_GET['activate'])&&isset($_GET['table'])) {
    $id = $_GET['id'];
    $category->activate($id);
    header('Location: manage-category.php');
}
if (isset($_GET['inactivate'])&&isset($_GET['table'])) {
    $id = $_GET['id'];
    $blog->inactivate($id);
    header('Location: manage-blog.php');
}
if (isset($_GET['activate'])&&isset($_GET['table'])) {
    $id = $_GET['id'];
    $blog->activate($id);
    header('Location: manage-blog.php');
}
