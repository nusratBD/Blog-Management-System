
<?php
require_once 'header.php';

require_once 'vendor/autoload.php';

$category = new App\classes\Category();
$blog = new App\classes\Blog();
$selectActiveCategory = $category->selectActiveCategory();


$id2 = $_GET['id'];

$data = $blog->categoryPosts($id2);
$title = $category->selectCategoryTitle($id2);
$row2 = mysqli_fetch_assoc($title)
?>

<!-- Page Content -->
<div class="container">

    <div class="row">

        <!-- Blog Entries Column -->
        <div class="col-md-8">

            <h1 class="my-4">All
                Posts on <?php echo $row2['cat_name'];?>
            </h1>

            <!-- Blog Post -->
            <?php
            $sl = 1;
            while ($row = mysqli_fetch_assoc($data)) {
                ?>
                <div class="card mb-4">
                    <img class="card-img-top" src="uploads/<?php echo $row['photo']; ?>" alt="Card image cap" style="width:100%; height: 300px;">
                    <div class="card-body">
                        <h2 class="card-title"><?php echo $row['title']; ?></h2>
                        <p class="card-text"><?php echo substr($row['content'],0,800); ?>....</p>
                        <a href="single-post.php?id=<?php echo $row['id']; ?>" class="btn btn-primary">Read More &rarr;</a>
                    </div>
                    <div class="card-footer text-muted">
                        Posted on <?php echo $row['create_time']; ?> by 
                        <a href="#"><?php echo $row['post_by']; ?></a>
                    </div>
                </div>
           

            <?php } ?>

            <!-- Pagination -->
            <ul class="pagination justify-content-center mb-4">
                <li class="page-item">
                    <a class="page-link" href="#">&larr; Older</a>
                </li>
                <li class="page-item disabled">
                    <a class="page-link" href="#">Newer &rarr;</a>
                </li>
            </ul>

        </div>

        <?php require_once 'sidebar.php'; ?>

    </div>
    <!-- /.row -->

</div>
<!-- /.container -->

<?php require_once 'footer.php'; ?>

