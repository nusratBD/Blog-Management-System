<?php

require_once '../vendor/autoload.php';

$category = new App\classes\Category();
$blog = new App\classes\Blog();
if(isset($_GET['table'])){
    $id = $_GET['id'];
    $category->delete($id);
    header('LOcation: manage-category.php');
}
if(isset($_GET['table'])){
    $id = $_GET['id'];
    $blog->delete($id);
    header('LOcation: manage-blog.php');
}