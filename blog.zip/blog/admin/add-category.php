<?php 
require_once 'header.php';
require_once '../vendor/autoload.php';

$update = new App\classes\Category();
if (isset($_POST['add_cat'])) {
$addMessage = $update->addCategory($_POST);
		
}
?>
              <div class="row">
                 <div class="col-lg-3"></div>
                  <div class="col-lg-6">
                      <section class="card">
                          <header class="card-header">
                              <h4>Add Category</h4>
                          </header>
                          <div class="card-body">
                              <form action="" method="POST">
                              	<?php if (isset($addMessage)) { ?>
                    
                <div class="alert alert-success text-center" role="alert" style="color: red;"><?php echo $addMessage; ?><button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button></div>
                    
                    <?php } else{
                    	
                    } ?>
                   
                             <div class="form-group row">
                                      <label for="inputEmail3" class="col-sm-4 col-form-label">Category Name</label>
                                      <div class="col-sm-8">
                                          <input type="text" class="form-control" id="inputEmail3" placeholder="Category Name" name="cat_name">
                                      </div>
                                  </div>
                                 
                                  <fieldset class="form-group">
                                      <div class="row">
                                          <legend class="col-form-label col-sm-4 pt-0">Status</legend>
                                          <div class="col-sm-8">
                                              <div class="form-check">
                                                  <input class="form-check-input" type="radio" name="status" id="gridRadios1" value="1" checked="">
                                                  <label class="form-check-label" for="gridRadios1">
                                                      Active
                                                  </label>
                                              </div>
                                              <div class="form-check">
                                                  <input class="form-check-input" type="radio" name="status" id="gridRadios2" value="0">
                                                  <label class="form-check-label" for="gridRadios2">
                                                      Inactive
                                                  </label>
                                              </div>
                                              
                                          </div>
                                      </div>
                                  </fieldset>
                                
                                  <div class="form-group row">
                                      <div class="col-sm-10">
                                          <button type="submit" class="btn btn-primary" name="add_cat">Add Now</button>
                                      </div>
                                  </div>
                              </form>
                          </div>
                      </section>

                  </div>
              </div>
 <?php 
require_once 'footer.php';
?>            
    